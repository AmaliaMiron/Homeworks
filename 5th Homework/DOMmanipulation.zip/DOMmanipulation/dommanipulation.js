function actionForm() {


    var name = document.forms["complete"].value;
    var email = document.forms["complete"].value;
    var subject =document.forms["complete"].value;

    if (name, email, subject == "") {

      var a = document.getElementById("name").setAttribute("style","background-color: red; border-radius:5px;" )
      var b = document.getElementById("email").setAttribute("style","background-color: red;border-radius:5px; ")
      var c = document.getElementById("subject").setAttribute("style","background-color: red;border-radius:5px;")

       
      
    } 
        else {  
             var div = document.getElementById("log") ;    

               div.style.visibility = "initial";

            }
  }